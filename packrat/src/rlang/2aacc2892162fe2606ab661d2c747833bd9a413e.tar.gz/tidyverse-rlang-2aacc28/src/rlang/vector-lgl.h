#ifndef RLANG_VECTOR_LGL_H
#define RLANG_VECTOR_LGL_H


bool r_as_bool(SEXP x);


#endif
