#ifndef RLANG_QUO_H
#define RLANG_QUO_H


bool r_quo_is_missing(SEXP x);


#endif
